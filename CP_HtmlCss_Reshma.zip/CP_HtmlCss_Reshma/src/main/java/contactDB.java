import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

public class contactDB {
	Connection con;
	Statement stmt;
	PreparedStatement pst;
	public contactDB(){

		try{  
			Class.forName("com.mysql.cj.jdbc.Driver");  
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/log","root","Reshmanl@99");  
			
			stmt=con.createStatement(); 
			
		}catch(Exception e){
			System.out.println(e);
		}  
	}
	public int insert(String name,String email,int mobile,String sub,String msg) throws SQLException {
		
		String str="insert into con(name,email,mobile,sub,msg) values('"+name+"','"+email+"','"+mobile+"','"+sub+"','"+"','"+msg+"')";
		System.out.println(name+email+mobile+sub+msg);
		stmt.executeUpdate(str);
		System.out.println(name+email+mobile+sub+msg);
		return 1;
	}

}
