



import java.sql.*;


public class DbConn {
	Connection con;
	Statement stmt;
	PreparedStatement pst;
	public DbConn(){

		try{  
			Class.forName("com.mysql.cj.jdbc.Driver");  
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/log","root","Reshmanl@99");  
			
			stmt=con.createStatement(); 
			
		}catch(Exception e){
			System.out.println(e);
		}  
	}
	public int insert(String name,String uname,String pswd,int ph) throws SQLException {
		
		String str="insert into reg1(name,username,password,phone) values('"+name+"','"+uname+"','"+pswd+"',"+ph+")";
		System.out.println(name+uname+pswd+ph);
		stmt.executeUpdate(str);
		System.out.println(name+uname+pswd+ph);
		return 1;
	}
	
	public int login(String uname,String pswd) throws SQLException {
		String str = "select * from reg1 where username='"+uname+"' and password='"+pswd+"'";
		ResultSet rs = stmt.executeQuery(str);
		if(rs.next()) 
			return 1;
		
		else
			return 0;
	}
	public void delete(int id) throws SQLException {
		String str="delete from reg1 where id="+id;
		stmt.executeUpdate(str);
	}
	public ResultSet display() throws SQLException {
		String str="select * from reg1";
		ResultSet rs=stmt.executeQuery(str);
		return rs;
	}
	
}
